# Queondaelfinde
repositorio del proyecto "Que onda el finde en Paraná?"
es una web para descubrir todo lo que se puede hacer en la ciudad del mate
dirigida para todo tipo de publico
con un diseño basado en imagenes reales en el cual el usuario sienta las ganas de conocer o realizar tal actividad.
