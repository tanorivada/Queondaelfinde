$(document).ready(function(){
    $(".catedral").hover(
        function() {$(this).attr("src","Imagenes/historia catedral.jpg");},
        function() {$(this).attr("src","Imagenes/catedral.jpg");
    });
});

$(document).ready(function(){
    $(".remo").hover(
        function() {$(this).attr("src","Imagenes/remo2.jpg");},
        function() {$(this).attr("src","Imagenes/remo.jpg");
    });
});

$(document).ready(function(){
    $(".bicicleta").hover(
        function() {$(this).attr("src","./Imagenes/bici2.jpg");},
        function() {$(this).attr("src","Imagenes/bicicleta.jpg.png");
    });
});

$(document).ready(function(){
    $(".parques").hover(
        function() {$(this).attr("src","Imagenes/Parques2.jpg");},
        function() {$(this).attr("src","Imagenes/parques.jpg");
    });
});

$(document).ready(function(){
    $(".fuente").hover(
        function() {$(this).attr("src","Imagenes/Costanera.jpg");},
        function() {$(this).attr("src","Imagenes/fuente.jpg");
    });
});

$(document).ready(function(){
    $(".mate").hover(
        function() {$(this).attr("src","Imagenes/mates2.jpg");},
        function() {$(this).attr("src","Imagenes/mates.jpg");
    });
});

$(document).ready(function(){
    $(".restauran").hover(
        function() {$(this).attr("src","Imagenes/Restauran.jpg");},
        function() {$(this).attr("src","Imagenes/restauran plaza.jpg");
    });
});

$(document).ready(function(){
    $(".comida").hover(
        function() {$(this).attr("src","Imagenes/gastronomia.jpg");},
        function() {$(this).attr("src","Imagenes/asado.jpg");
    });
});

$(document).ready(function(){
    $(".coctel").hover(
        function() {$(this).attr("src","Imagenes/Bares y Pubs.jpg");},
        function() {$(this).attr("src","Imagenes/coctel.jpg");
    });
});

$(document).ready(function(){
    $(".boliche").hover(
        function() {$(this).attr("src","Imagenes/Discotecas.jpg");},
        function() {$(this).attr("src","Imagenes/boliche.jpg");
    });
});

$(document).ready(function(){
    $(".recitales").hover(
        function() {$(this).attr("src","Imagenes/Recitales2.jpg");},
        function() {$(this).attr("src","Imagenes/recitales.jpg");
    });
});

$(document).ready(function(){
    $(".ffd").hover(
        function() {$(this).attr("src","Imagenes/ffd2.jpg");},
        function() {$(this).attr("src","Imagenes/fdd.jpg.png");
    });
});